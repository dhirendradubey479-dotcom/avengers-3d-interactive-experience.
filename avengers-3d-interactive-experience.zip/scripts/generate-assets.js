import fs from 'fs';
import { execSync } from 'child_process';
import path from 'path';

const characters = [
  {
    filename: 'thor.jpg',
    name: 'THOR',
    title: 'GOD OF THUNDER // ASGARD',
    primary: '#00d4ff',
    secondary: '#1e3a8a',
    accent: '#38bdf8',
    dark: '#030712',
    symbol: `
      <!-- Lightning Hammer & Stormbreaker -->
      <g transform="translate(400, 480)">
        <!-- Storm clouds & lightning bolts -->
        <path d="M-280,-200 L-100,-40 L-160,-20 L0,160 L-40,20 L120,60" stroke="#38bdf8" stroke-width="4" fill="none" opacity="0.8" filter="url(#glow)"/>
        <path d="M260,-220 L120,-60 L180,-30 L20,180 L80,40 L-60,70" stroke="#00d4ff" stroke-width="5" fill="none" opacity="0.9" filter="url(#glow)"/>
        <!-- Mjolnir silhouette -->
        <rect x="-90" y="-140" width="180" height="110" rx="14" fill="#334155" stroke="#94a3b8" stroke-width="5"/>
        <line x1="0" y1="-30" x2="0" y2="170" stroke="#475569" stroke-width="22" stroke-linecap="round"/>
        <line x1="0" y1="-20" x2="0" y2="160" stroke="#78350f" stroke-width="14" stroke-dasharray="16,6"/>
        <!-- Hammer Rune Engraving -->
        <circle cx="0" cy="-85" r="30" stroke="#38bdf8" stroke-width="4" fill="none" filter="url(#glow)"/>
        <path d="M-15,-85 L15,-85 M0,-100 L0,-70 M-10,-95 L10,-75 M10,-95 L-10,-75" stroke="#e0f2fe" stroke-width="3"/>
        <!-- Divine Aura Rays -->
        <circle cx="0" cy="-85" r="160" stroke="#00d4ff" stroke-width="2" stroke-dasharray="8,12" opacity="0.5" fill="none"/>
      </g>
    `
  },
  {
    filename: 'black-panther.jpg',
    name: 'BLACK PANTHER',
    title: "KING T'CHALLA // WAKANDA",
    primary: '#c084fc',
    secondary: '#581c87',
    accent: '#e879f9',
    dark: '#05020a',
    symbol: `
      <!-- Vibranium Panther Mask & Kinetic Weave -->
      <g transform="translate(400, 480)">
        <!-- Kinetic energy pulse rings -->
        <ellipse cx="0" cy="0" rx="260" ry="260" stroke="#a855f7" stroke-width="3" stroke-dasharray="14,14" fill="none" opacity="0.4" filter="url(#glow)"/>
        <polygon points="0,-180 140,-40 90,140 -90,140 -140,-40" fill="#180d28" stroke="#a855f7" stroke-width="5"/>
        <!-- Panther Ears -->
        <polygon points="-110,-120 -150,-240 -80,-160" fill="#2e1065" stroke="#c084fc" stroke-width="4"/>
        <polygon points="110,-120 150,-240 80,-160" fill="#2e1065" stroke="#c084fc" stroke-width="4"/>
        <!-- Vibranium Eyes -->
        <polygon points="-70,-60 -25,-40 -60,-25" fill="#e879f9" filter="url(#glow)"/>
        <polygon points="70,-60 25,-40 60,-25" fill="#e879f9" filter="url(#glow)"/>
        <!-- Wakandan Teeth Necklace Pattern -->
        <path d="M-100,80 Q0,160 100,80" stroke="#c084fc" stroke-width="8" stroke-dasharray="18,12" fill="none" filter="url(#glow)"/>
        <!-- Claw Slashes -->
        <path d="M-220,-80 Q-160,20 -180,120 M-200,-100 Q-140,0 -160,100 M-180,-120 Q-120,-20 -140,80" stroke="#c084fc" stroke-width="4" stroke-linecap="round" fill="none" filter="url(#glow)"/>
        <path d="M220,-80 Q160,20 180,120 M200,-100 Q140,0 160,100 M180,-120 Q120,-20 140,80" stroke="#c084fc" stroke-width="4" stroke-linecap="round" fill="none" filter="url(#glow)"/>
      </g>
    `
  },
  {
    filename: 'black-widow.jpg',
    name: 'BLACK WIDOW',
    title: 'NATASHA ROMANOFF // ESPIONAGE',
    primary: '#ef4444',
    secondary: '#881337',
    accent: '#f87171',
    dark: '#080103',
    symbol: `
      <!-- Red Hourglass & Shock Batons -->
      <g transform="translate(400, 480)">
        <!-- Crossed shock batons -->
        <line x1="-200" y1="-200" x2="200" y2="200" stroke="#94a3b8" stroke-width="16" stroke-linecap="round"/>
        <line x1="-200" y1="-200" x2="200" y2="200" stroke="#38bdf8" stroke-width="6" stroke-dasharray="24,12" filter="url(#glow)"/>
        <line x1="200" y1="-200" x2="-200" y2="200" stroke="#94a3b8" stroke-width="16" stroke-linecap="round"/>
        <line x1="200" y1="-200" x2="-200" y2="200" stroke="#38bdf8" stroke-width="6" stroke-dasharray="24,12" filter="url(#glow)"/>
        <!-- Hourglass Badge -->
        <polygon points="-100,-140 100,-140 0,0" fill="#dc2626" stroke="#f87171" stroke-width="4" filter="url(#glow)"/>
        <polygon points="-100,140 100,140 0,0" fill="#b91c1c" stroke="#f87171" stroke-width="4" filter="url(#glow)"/>
        <!-- Tactical Crosshair Rings -->
        <circle cx="0" cy="0" r="220" stroke="#ef4444" stroke-width="2" stroke-dasharray="10,20" fill="none" opacity="0.6"/>
        <circle cx="0" cy="0" r="140" stroke="#ffffff" stroke-width="1.5" stroke-dasharray="6,14" fill="none" opacity="0.4"/>
      </g>
    `
  },
  {
    filename: 'spider-man.jpg',
    name: 'SPIDER-MAN',
    title: 'PETER PARKER // QUEENS',
    primary: '#38bdf8',
    secondary: '#b91c1c',
    accent: '#e11d48',
    dark: '#030712',
    symbol: `
      <!-- Web Matrix & Spider Insignia -->
      <g transform="translate(400, 480)">
        <!-- Web Spokes -->
        ${Array.from({length: 16}).map((_, i) => {
          const angle = (i * 22.5 * Math.PI) / 180;
          const x = Math.cos(angle) * 260;
          const y = Math.sin(angle) * 260;
          return `<line x1="0" y1="0" x2="${x}" y2="${y}" stroke="#e2e8f0" stroke-width="2" opacity="0.3"/>`;
        }).join('')}
        <!-- Web Rings -->
        <circle cx="0" cy="0" r="70" stroke="#e2e8f0" stroke-width="2.5" fill="none" opacity="0.4"/>
        <circle cx="0" cy="0" r="140" stroke="#e2e8f0" stroke-width="2.5" fill="none" opacity="0.4"/>
        <circle cx="0" cy="0" r="210" stroke="#e2e8f0" stroke-width="2.5" fill="none" opacity="0.4"/>
        <!-- Spider Emblem Body -->
        <ellipse cx="0" cy="0" rx="22" ry="42" fill="#0f172a" stroke="#e11d48" stroke-width="4" filter="url(#glow)"/>
        <circle cx="0" cy="-52" r="18" fill="#0f172a" stroke="#e11d48" stroke-width="4"/>
        <!-- Spider Legs -->
        <path d="M-15,-20 Q-70,-90 -120,-80 M15,-20 Q70,-90 120,-80" stroke="#e11d48" stroke-width="7" stroke-linecap="round" fill="none" filter="url(#glow)"/>
        <path d="M-20,-5 Q-90,-40 -140,-20 M20,-5 Q90,-40 140,-20" stroke="#e11d48" stroke-width="7" stroke-linecap="round" fill="none" filter="url(#glow)"/>
        <path d="M-20,10 Q-90,40 -130,80 M20,10 Q90,40 130,80" stroke="#38bdf8" stroke-width="7" stroke-linecap="round" fill="none" filter="url(#glow)"/>
        <path d="M-15,25 Q-60,90 -90,140 M15,25 Q60,90 90,140" stroke="#38bdf8" stroke-width="7" stroke-linecap="round" fill="none" filter="url(#glow)"/>
      </g>
    `
  },
  {
    filename: 'iron-man.jpg',
    name: 'IRON MAN',
    title: 'TONY STARK // STARK TOWER',
    primary: '#f59e0b',
    secondary: '#991b1b',
    accent: '#38bdf8',
    dark: '#0a0302',
    symbol: `
      <!-- Mark L Arc Reactor & Nanotech HUD -->
      <g transform="translate(400, 480)">
        <!-- Outer Reactor Rings -->
        <circle cx="0" cy="0" r="220" stroke="#f59e0b" stroke-width="3" stroke-dasharray="18,12" fill="none" opacity="0.6"/>
        <polygon points="0,-160 138,-80 138,80 0,160 -138,80 -138,-80" stroke="#ef4444" stroke-width="4" fill="none" opacity="0.8"/>
        <!-- Nanotech Core -->
        <circle cx="0" cy="0" r="100" fill="#0f172a" stroke="#38bdf8" stroke-width="6" filter="url(#glow)"/>
        <circle cx="0" cy="0" r="60" fill="#1e293b" stroke="#67e8f9" stroke-width="4"/>
        <polygon points="0,-45 39,22 -39,22" fill="#e0f2fe" filter="url(#glow)"/>
        <!-- Repulsor Radial Beams -->
        ${Array.from({length: 12}).map((_, i) => {
          const angle = (i * 30 * Math.PI) / 180;
          const x1 = Math.cos(angle) * 110;
          const y1 = Math.sin(angle) * 110;
          const x2 = Math.cos(angle) * 180;
          const y2 = Math.sin(angle) * 180;
          return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#f59e0b" stroke-width="3" opacity="0.7"/>`;
        }).join('')}
      </g>
    `
  },
  {
    filename: 'hulk.jpg',
    name: 'HULK',
    title: 'BRUCE BANNER // GAMMA LAB',
    primary: '#10b981',
    secondary: '#064e3b',
    accent: '#34d399',
    dark: '#020904',
    symbol: `
      <!-- Gamma Biohazard & Radiation Fist -->
      <g transform="translate(400, 480)">
        <!-- Gamma Shockwave Tremor Rings -->
        <ellipse cx="0" cy="0" rx="240" ry="240" stroke="#10b981" stroke-width="4" stroke-dasharray="16,20" fill="none" opacity="0.5" filter="url(#glow)"/>
        <ellipse cx="0" cy="0" rx="170" ry="170" stroke="#34d399" stroke-width="3" stroke-dasharray="8,12" fill="none" opacity="0.7"/>
        <!-- Gamma Biohazard Trefoil -->
        <circle cx="0" cy="-70" r="65" fill="#065f46" stroke="#10b981" stroke-width="6" filter="url(#glow)"/>
        <circle cx="-60" cy="40" r="65" fill="#065f46" stroke="#10b981" stroke-width="6" filter="url(#glow)"/>
        <circle cx="60" cy="40" r="65" fill="#065f46" stroke="#10b981" stroke-width="6" filter="url(#glow)"/>
        <circle cx="0" cy="0" r="30" fill="#022c22" stroke="#34d399" stroke-width="5"/>
        <!-- Shockwave Fissures -->
        <path d="M-180,180 L-100,100 L-40,140 L0,60 L60,130 L140,80 L200,170" stroke="#10b981" stroke-width="5" fill="none" opacity="0.8" filter="url(#glow)"/>
      </g>
    `
  },
  {
    filename: 'hawkeye.jpg',
    name: 'HAWKEYE',
    title: 'CLINT BARTON // STRIKE TEAM',
    primary: '#a855f7',
    secondary: '#3b0764',
    accent: '#c084fc',
    dark: '#06020c',
    symbol: `
      <!-- Recurve Bow & Optical Crosshairs -->
      <g transform="translate(400, 480)">
        <!-- Bow Arc -->
        <path d="M-160,-190 Q-230,0 -160,190" stroke="#9333ea" stroke-width="12" stroke-linecap="round" fill="none" filter="url(#glow)"/>
        <line x1="-160" y1="-190" x2="-160" y2="190" stroke="#e9d5ff" stroke-width="3" opacity="0.6"/>
        <!-- Arrow -->
        <line x1="-190" y1="0" x2="210" y2="0" stroke="#a855f7" stroke-width="7" stroke-linecap="round" filter="url(#glow)"/>
        <polygon points="210,0 170,-20 180,0 170,20" fill="#c084fc"/>
        <polygon points="-190,0 -160,-16 -170,0 -160,16" fill="#7e22ce"/>
        <!-- Sniper Reticle -->
        <circle cx="60" cy="0" r="140" stroke="#c084fc" stroke-width="3" stroke-dasharray="12,18" fill="none" opacity="0.7"/>
        <circle cx="60" cy="0" r="70" stroke="#a855f7" stroke-width="2" fill="none" opacity="0.8"/>
        <line x1="60" y1="-160" x2="60" y2="160" stroke="#c084fc" stroke-width="2" stroke-dasharray="8,8" opacity="0.5"/>
        <line x1="-100" y1="0" x2="220" y2="0" stroke="#c084fc" stroke-width="2" stroke-dasharray="8,8" opacity="0.5"/>
      </g>
    `
  },
  {
    filename: 'captain-america.jpg',
    name: 'CAPTAIN AMERICA',
    title: 'STEVE ROGERS // FIRST AVENGER',
    primary: '#3b82f6',
    secondary: '#b91c1c',
    accent: '#ffffff',
    dark: '#030712',
    symbol: `
      <!-- Vibranium Star Shield -->
      <g transform="translate(400, 480)">
        <!-- Outer Red Ring -->
        <circle cx="0" cy="0" r="220" fill="#dc2626" stroke="#f87171" stroke-width="4"/>
        <!-- White Ring -->
        <circle cx="0" cy="0" r="175" fill="#f1f5f9" stroke="#cbd5e1" stroke-width="3"/>
        <!-- Inner Red Ring -->
        <circle cx="0" cy="0" r="130" fill="#dc2626" stroke="#f87171" stroke-width="3"/>
        <!-- Blue Center -->
        <circle cx="0" cy="0" r="85" fill="#1d4ed8" stroke="#60a5fa" stroke-width="4" filter="url(#glow)"/>
        <!-- Vibranium Five-Point Star -->
        <polygon points="
          0,-75 22,-24 75,-24 32,9
          48,61 0,28 -48,61 -32,9
          -75,-24 -22,-24
        " fill="#ffffff" filter="url(#glow)"/>
        <!-- Shield Metallic Reflections -->
        <path d="M-150,-150 Q0,-60 150,-150" stroke="#ffffff" stroke-width="4" opacity="0.4" fill="none"/>
      </g>
    `
  },
  {
    filename: 'doctor-strange.jpg',
    name: 'DOCTOR STRANGE',
    title: 'STEPHEN STRANGE // KAMAR-TAJ',
    primary: '#ea580c',
    secondary: '#b45309',
    accent: '#fbbf24',
    dark: '#0a0401',
    symbol: `
      <!-- Eldritch Mystic Mandala & Eye of Agamotto -->
      <g transform="translate(400, 480)">
        <!-- Eldritch Mandala Squares -->
        <rect x="-140" y="-140" width="280" height="280" stroke="#f97316" stroke-width="3" fill="none" opacity="0.8" filter="url(#glow)"/>
        <rect x="-140" y="-140" width="280" height="280" stroke="#fbbf24" stroke-width="3" fill="none" transform="rotate(45)" opacity="0.8" filter="url(#glow)"/>
        <!-- Concentric Rune Circles -->
        <circle cx="0" cy="0" r="230" stroke="#f59e0b" stroke-width="3" stroke-dasharray="14,10" fill="none" filter="url(#glow)"/>
        <circle cx="0" cy="0" r="185" stroke="#ea580c" stroke-width="2" stroke-dasharray="6,8" fill="none"/>
        <circle cx="0" cy="0" r="100" stroke="#fbbf24" stroke-width="4" fill="none"/>
        <!-- Eye of Agamotto Center -->
        <ellipse cx="0" cy="0" rx="70" ry="42" fill="#180e04" stroke="#10b981" stroke-width="5" filter="url(#glow)"/>
        <circle cx="0" cy="0" r="22" fill="#10b981" filter="url(#glow)"/>
        <!-- Eldritch Sparks -->
        ${Array.from({length: 16}).map((_, i) => {
          const angle = (i * 22.5 * Math.PI) / 180;
          const dist = 210 + (i % 3) * 20;
          const x = Math.cos(angle) * dist;
          const y = Math.sin(angle) * dist;
          return `<circle cx="${x}" cy="${y}" r="3" fill="#fbbf24" filter="url(#glow)"/>`;
        }).join('')}
      </g>
    `
  }
];

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

characters.forEach(char => {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 1067" width="800" height="1067">
    <defs>
      <linearGradient id="bgGrad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="${char.dark}"/>
        <stop offset="45%" stop-color="${char.secondary}" stop-opacity="0.6"/>
        <stop offset="75%" stop-color="${char.dark}"/>
        <stop offset="100%" stop-color="#000000"/>
      </linearGradient>
      <radialGradient id="auraGrad" cx="50%" cy="45%" r="50%">
        <stop offset="0%" stop-color="${char.primary}" stop-opacity="0.5"/>
        <stop offset="60%" stop-color="${char.secondary}" stop-opacity="0.15"/>
        <stop offset="100%" stop-color="transparent" stop-opacity="0"/>
      </radialGradient>
      <filter id="glow" x="-30%" y="-30%" width="160%" height="160%">
        <feGaussianBlur stdDeviation="8" result="blur" />
        <feMerge>
          <feMergeNode in="blur" />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
      <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="${char.primary}" stroke-width="0.75" stroke-opacity="0.12"/>
      </pattern>
    </defs>

    <!-- Deep canvas -->
    <rect width="800" height="1067" fill="url(#bgGrad)"/>
    <rect width="800" height="1067" fill="url(#grid)"/>
    <rect width="800" height="1067" fill="url(#auraGrad)"/>

    <!-- HUD Tactical Frame -->
    <rect x="25" y="25" width="750" height="1017" fill="none" stroke="${char.primary}" stroke-width="1.5" stroke-opacity="0.4"/>
    <!-- Corner brackets -->
    <path d="M 25 70 L 25 25 L 70 25" fill="none" stroke="${char.accent}" stroke-width="4"/>
    <path d="M 775 70 L 775 25 L 730 25" fill="none" stroke="${char.accent}" stroke-width="4"/>
    <path d="M 25 997 L 25 1042 L 70 1042" fill="none" stroke="${char.accent}" stroke-width="4"/>
    <path d="M 775 997 L 775 1042 L 730 1042" fill="none" stroke="${char.accent}" stroke-width="4"/>

    <!-- Header HUD telemetry labels -->
    <text x="50" y="70" font-family="'JetBrains Mono', monospace, sans-serif" font-size="14" fill="${char.primary}" letter-spacing="3" opacity="0.9">TACTICAL SPECIFICATION // CLASSIFIED</text>
    <text x="750" y="70" text-anchor="end" font-family="'JetBrains Mono', monospace, sans-serif" font-size="14" fill="#94a3b8" letter-spacing="2">AVENGERS INITIATIVE</text>

    <!-- Central High-Impact Vector Symbol -->
    ${char.symbol}

    <!-- Lower Title Banner -->
    <rect x="50" y="870" width="700" height="120" rx="12" fill="rgba(10, 15, 30, 0.85)" stroke="${char.primary}" stroke-width="1.5" stroke-opacity="0.5"/>
    <text x="80" y="920" font-family="'Cinzel', 'Arial Black', sans-serif" font-weight="900" font-size="38" fill="#ffffff" letter-spacing="6">${char.name}</text>
    <text x="80" y="960" font-family="'JetBrains Mono', monospace, sans-serif" font-size="16" fill="${char.accent}" letter-spacing="3">${char.title}</text>
    <circle cx="710" cy="930" r="16" fill="none" stroke="${char.primary}" stroke-width="2" stroke-dasharray="4,4"/>
    <circle cx="710" cy="930" r="6" fill="${char.accent}"/>

    <!-- Scanline Overlay -->
    <line x1="25" y1="200" x2="775" y2="200" stroke="${char.accent}" stroke-width="1" opacity="0.25"/>
    <line x1="25" y1="840" x2="775" y2="840" stroke="${char.accent}" stroke-width="1" opacity="0.25"/>
  </svg>`;

  const tempSvgPath = path.join('/tmp', `${char.filename}.svg`);
  const finalJpgPath = path.join(publicDir, char.filename);
  fs.writeFileSync(tempSvgPath, svg);
  try {
    execSync(`ffmpeg -y -i "${tempSvgPath}" "${finalJpgPath}"`, { stdio: 'inherit' });
    console.log(`Generated: ${finalJpgPath}`);
  } catch (err) {
    console.error(`Error converting ${char.filename}:`, err);
  }
});
