import { useState, useEffect } from 'react';
import { OPERATIVES, Operative } from './data/operatives';
import { soundEngine } from './utils/audio';
import { ParticleCanvas } from './components/ParticleCanvas';
import { CinematicBoot } from './components/CinematicBoot';
import { OperativeCard } from './components/OperativeCard';
import { OperativeShowcase } from './components/OperativeShowcase';
import { TeamSynchronization } from './components/TeamSynchronization';
import { Volume2, VolumeX, Shield, Users, Radio, RotateCcw } from 'lucide-react';

export default function App() {
  const [isBooting, setIsBooting] = useState(true);
  const [selectedOperative, setSelectedOperative] = useState<Operative>(OPERATIVES[4]); // Default Iron Man
  const [switchingStage, setSwitchingStage] = useState<number>(0);
  const [isMuted, setIsMuted] = useState(false);
  const [activeTab, setActiveTab] = useState<'showcase' | 'grid' | 'synapse'>('showcase');

  // Trigger four-stage switching pipeline when operative changes
  const handleSelectOperative = (newOp: Operative) => {
    if (newOp.id === selectedOperative.id && switchingStage === 0) return;

    // STEP 01 — Telemetry Exit
    setSwitchingStage(1);
    soundEngine.playScanlinePass();

    // STEP 02 — Palette Shift
    setTimeout(() => {
      setSelectedOperative(newOp);
      setSwitchingStage(2);

      // STEP 03 — Photo Materialize
      setTimeout(() => {
        setSwitchingStage(3);

        // STEP 04 — Audio & Voice
        setTimeout(() => {
          setSwitchingStage(4);
          soundEngine.playRecalibrationSweep();
          soundEngine.speakDialogue(newOp.voiceQuote, newOp.id);

          setTimeout(() => {
            setSwitchingStage(0); // Return to idle/ready
          }, 400);
        }, 120);
      }, 150);
    }, 180);
  };

  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    soundEngine.setMuted(nextMuted);
    if (!nextMuted) {
      soundEngine.playClick(1200, 0.03);
    }
  };

  const handleReboot = () => {
    setIsBooting(true);
    soundEngine.playClick(800, 0.04);
  };

  useEffect(() => {
    // Keyboard shortcut ESC to reboot or cancel
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isBooting) {
        // Can open menu or reboot
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isBooting]);

  return (
    <div
      className="min-h-screen text-slate-100 flex flex-col relative transition-colors duration-700 overflow-x-hidden"
      style={{
        background: selectedOperative.bgGradient,
      }}
    >
      {/* 60FPS Ambient Particle Canvas tinted to selected operative */}
      <ParticleCanvas
        primaryColor={selectedOperative.primaryColor}
        glowColor={selectedOperative.glowColor}
        isOverdrive={activeTab === 'synapse'}
      />

      {/* Subtle Holographic Grid Pattern */}
      <div className="fixed inset-0 hologram-grid pointer-events-none opacity-40 z-0" />

      {/* Phase 1–2: Cinematic Boot HUD Activation */}
      {isBooting && (
        <CinematicBoot
          onComplete={() => {
            setIsBooting(false);
            // Auto-voice introduction for default operative
            setTimeout(() => {
              soundEngine.playRecalibrationSweep();
              soundEngine.speakDialogue(selectedOperative.voiceQuote, selectedOperative.id);
            }, 300);
          }}
        />
      )}

      {/* Top Bar Contract (Strict 3-zone standard) */}
      <header className="sticky top-0 z-30 flex items-center justify-between px-6 py-4 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3">
          <div
            className="w-2.5 h-2.5 rounded-full transition-colors duration-500"
            style={{ backgroundColor: selectedOperative.primaryColor }}
          />
          <span className="font-cinzel text-lg md:text-xl font-bold tracking-widest text-white uppercase truncate">
            Avengers 3D Experience
          </span>
        </div>

        {/* Zone 2: Clean navigation controls */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800 text-xs font-mono-code">
          <button
            onClick={() => setActiveTab('showcase')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'showcase'
                ? 'bg-slate-800 text-white shadow-sm border border-slate-700'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>3D SHOWCASE</span>
          </button>

          <button
            onClick={() => setActiveTab('grid')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'grid'
                ? 'bg-slate-800 text-white shadow-sm border border-slate-700'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>ALL 9 OPERATIVES</span>
          </button>

          <button
            onClick={() => setActiveTab('synapse')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'synapse'
                ? 'bg-cyan-500/20 text-cyan-300 shadow-sm border border-cyan-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span>TEAM SYNAPSE [PHASE 7]</span>
          </button>
        </nav>

        {/* Zone 3: Primary interactive actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleToggleMute}
            className={`p-2 rounded-lg border transition-colors flex items-center gap-1.5 text-xs font-mono-code cursor-pointer ${
              isMuted
                ? 'bg-red-950/40 border-red-800/60 text-red-300'
                : 'bg-slate-900 border-slate-700 text-cyan-300 hover:border-cyan-400'
            }`}
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            onClick={handleReboot}
            className="px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-mono-code transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Reboot HUD diagnostics"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">REBOOT HUD</span>
          </button>
        </div>
      </header>

      {/* Mobile Tab Selector (visible on small viewports) */}
      <div className="md:hidden flex items-center justify-around bg-slate-950/90 border-b border-slate-800 p-2 text-xs font-mono-code z-20">
        <button
          onClick={() => setActiveTab('showcase')}
          className={`px-3 py-1.5 rounded-lg ${
            activeTab === 'showcase' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'
          }`}
        >
          SHOWCASE
        </button>
        <button
          onClick={() => setActiveTab('grid')}
          className={`px-3 py-1.5 rounded-lg ${
            activeTab === 'grid' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'
          }`}
        >
          GRID (9)
        </button>
        <button
          onClick={() => setActiveTab('synapse')}
          className={`px-3 py-1.5 rounded-lg ${
            activeTab === 'synapse' ? 'bg-cyan-900/60 text-cyan-300 font-bold' : 'text-slate-400'
          }`}
        >
          SYNAPSE
        </button>
      </div>

      {/* Main Tactical Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 z-10 space-y-8">
        
        {/* Active Operative Horizontal Quick Selector Bar */}
        <section className="space-y-2">
          <div className="flex items-center justify-between text-xs font-mono-code text-slate-400">
            <span className="tracking-widest uppercase">
              TACTICAL ROSTER // SELECT OPERATIVE TO DEPLOY
            </span>
            <span className="text-[11px] text-slate-500">
              9/9 OPERATIVES READY
            </span>
          </div>

          {/* Scrollable Operatives Pill Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {OPERATIVES.map((op) => {
              const isCurrent = op.id === selectedOperative.id;
              return (
                <button
                  key={op.id}
                  onClick={() => handleSelectOperative(op)}
                  className={`flex items-center gap-2.5 px-3.5 py-2 rounded-xl border text-xs font-mono-code whitespace-nowrap transition-all duration-200 cursor-pointer shrink-0 ${
                    isCurrent
                      ? 'bg-slate-900 text-white shadow-md'
                      : 'bg-slate-950/70 border-slate-800/80 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                  }`}
                  style={{
                    borderColor: isCurrent ? op.primaryColor : undefined,
                    boxShadow: isCurrent ? `0 0 15px ${op.glowColor}` : undefined,
                  }}
                >
                  <img
                    src={op.image}
                    alt={op.name}
                    className="w-5 h-5 rounded-full object-cover border border-slate-700"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = op.referenceUrl;
                    }}
                  />
                  <span className="font-bold">{op.number}</span>
                  <span>{op.name}</span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Dynamic Viewport Sections */}
        {activeTab === 'showcase' && (
          <section className="space-y-8 animate-in fade-in duration-300">
            {/* 3D Showcase & 7-Bar Telemetry Engine */}
            <OperativeShowcase
              operative={selectedOperative}
              switchingStage={switchingStage}
              isMuted={isMuted}
              onToggleMute={handleToggleMute}
            />

            {/* Quick 9-Card Selection Grid below showcase */}
            <div className="space-y-4 pt-4">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <h3 className="font-cinzel text-base md:text-lg font-bold tracking-wider text-white">
                  3D Operative Selection Grid
                </h3>
                <span className="text-xs font-mono-code text-slate-400">
                  HOVER FOR 3D TILT · CLICK TO SWITCH
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {OPERATIVES.map((op) => (
                  <OperativeCard
                    key={op.id}
                    operative={op}
                    isActive={op.id === selectedOperative.id}
                    onSelect={handleSelectOperative}
                  />
                ))}
              </div>
            </div>
          </section>
        )}

        {activeTab === 'grid' && (
          <section className="space-y-6 animate-in fade-in duration-300">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h2 className="font-cinzel text-xl md:text-2xl font-bold tracking-wider text-white">
                  Complete 9-Operative Tactical Grid
                </h2>
                <p className="text-xs text-slate-400 font-mono-code mt-0.5">
                  Interactive 3D tilt cards with holographic scanlines & real-time telemetry
                </p>
              </div>
              <span className="text-xs font-mono-code text-cyan-400">
                ACTIVE: {selectedOperative.name}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {OPERATIVES.map((op) => (
                <OperativeCard
                  key={op.id}
                  operative={op}
                  isActive={op.id === selectedOperative.id}
                  onSelect={(op) => {
                    handleSelectOperative(op);
                    setActiveTab('showcase');
                  }}
                />
              ))}
            </div>
          </section>
        )}

        {activeTab === 'synapse' && (
          <section className="space-y-6 animate-in fade-in duration-300">
            <TeamSynchronization
              onSelectOperative={(op) => {
                handleSelectOperative(op);
                setActiveTab('showcase');
              }}
            />
          </section>
        )}

      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-900 bg-slate-950/90 py-5 px-6 z-10 backdrop-blur-md">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4 text-xs font-mono-code text-slate-500">
          <div className="flex items-center gap-3">
            <span className="text-slate-400">AVENGERS DEFENSE INITIATIVE</span>
            <span>·</span>
            <span>STARK INDUSTRIES SECURE PROTOCOL</span>
          </div>

          <div className="flex items-center gap-4">
            <span>9 OPERATIVES LOADED</span>
            <span>·</span>
            <span className="text-cyan-400">60 FPS VERIFIED</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
