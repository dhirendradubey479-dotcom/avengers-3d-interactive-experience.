// Web Audio Synthesizer & Web Speech API Engine

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private bootOsc: OscillatorNode | null = null;
  private bootGain: GainNode | null = null;

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    if (muted && this.bootGain) {
      this.bootGain.gain.setValueAtTime(0, this.ctx?.currentTime || 0);
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  // Start continuous power surge hum during boot
  public startBootHum(progress: number) {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    if (!this.bootOsc) {
      this.bootOsc = this.ctx.createOscillator();
      this.bootGain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      this.bootOsc.type = 'sawtooth';
      this.bootOsc.frequency.setValueAtTime(60, this.ctx.currentTime);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(250, this.ctx.currentTime);

      this.bootGain.gain.setValueAtTime(0.04, this.ctx.currentTime);

      this.bootOsc.connect(filter);
      filter.connect(this.bootGain);
      this.bootGain.connect(this.ctx.destination);
      this.bootOsc.start();
    }

    if (this.bootOsc && this.bootGain && this.ctx) {
      const targetFreq = 60 + (progress / 100) * 160;
      this.bootOsc.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 0.05);
      const targetGain = 0.03 + (progress / 100) * 0.05;
      this.bootGain.gain.setTargetAtTime(targetGain, this.ctx.currentTime, 0.05);
    }
  }

  public stopBootHum() {
    if (this.bootOsc) {
      try {
        this.bootOsc.stop();
        this.bootOsc.disconnect();
      } catch {
        // ignore
      }
      this.bootOsc = null;
      this.bootGain = null;
    }
  }

  // Tactile HUD tick sound
  public playClick(freq = 1200, duration = 0.03) {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(300, this.ctx.currentTime + duration);

    gain.gain.setValueAtTime(0.04, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + duration);
  }

  // Telemetry recalibration sweep chime
  public playRecalibrationSweep(pitchMultiplier = 1.0) {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const notes = [440, 554.37, 659.25, 880];
    notes.forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq * pitchMultiplier, this.ctx!.currentTime + idx * 0.04);

      gain.gain.setValueAtTime(0, this.ctx!.currentTime + idx * 0.04);
      gain.gain.linearRampToValueAtTime(0.03, this.ctx!.currentTime + idx * 0.04 + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx!.currentTime + idx * 0.04 + 0.3);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(this.ctx!.currentTime + idx * 0.04);
      osc.stop(this.ctx!.currentTime + idx * 0.04 + 0.35);
    });
  }

  // Scanline pass downward sweep
  public playScanlinePass() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(800, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(150, this.ctx.currentTime + 0.25);

    gain.gain.setValueAtTime(0.025, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.25);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.26);
  }

  // Climax heroic chord sequence: "AVENGERS ASSEMBLE"
  public playAssembleCrescendo() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const chordNotes = [
      { f: 130.81, time: 0, d: 3.5, type: 'sawtooth' as OscillatorType }, // C3
      { f: 196.00, time: 0.2, d: 3.2, type: 'sawtooth' as OscillatorType }, // G3
      { f: 261.63, time: 0.4, d: 3.0, type: 'triangle' as OscillatorType }, // C4
      { f: 329.63, time: 0.6, d: 2.8, type: 'triangle' as OscillatorType }, // E4
      { f: 392.00, time: 0.8, d: 2.6, type: 'sine' as OscillatorType },     // G4
      { f: 523.25, time: 1.0, d: 2.5, type: 'sine' as OscillatorType },     // C5
    ];

    chordNotes.forEach((n) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = n.type;
      osc.frequency.setValueAtTime(n.f, this.ctx!.currentTime + n.time);

      gain.gain.setValueAtTime(0.0001, this.ctx!.currentTime + n.time);
      gain.gain.linearRampToValueAtTime(0.06, this.ctx!.currentTime + n.time + 0.3);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx!.currentTime + n.time + n.d);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(this.ctx!.currentTime + n.time);
      osc.stop(this.ctx!.currentTime + n.time + n.d + 0.1);
    });
  }

  // Arc Reactor pulse
  public playReactorPulse() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(90, this.ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(140, this.ctx.currentTime + 0.15);
    osc.frequency.exponentialRampToValueAtTime(60, this.ctx.currentTime + 0.5);

    gain.gain.setValueAtTime(0.05, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.5);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.55);
  }

  // Web Speech API synthesis
  public speakDialogue(text: string, operativeId: string, onStart?: () => void, onEnd?: () => void) {
    if (this.isMuted || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);

    // Character specific vocal pitch and speed
    switch (operativeId) {
      case 'thor':
        utterance.pitch = 0.82;
        utterance.rate = 0.95;
        break;
      case 'black-panther':
        utterance.pitch = 0.92;
        utterance.rate = 0.92;
        break;
      case 'black-widow':
        utterance.pitch = 1.15;
        utterance.rate = 1.0;
        break;
      case 'spider-man':
        utterance.pitch = 1.18;
        utterance.rate = 1.08;
        break;
      case 'iron-man':
        utterance.pitch = 0.98;
        utterance.rate = 1.05;
        break;
      case 'hulk':
        utterance.pitch = 0.65;
        utterance.rate = 0.85;
        break;
      case 'hawkeye':
        utterance.pitch = 0.95;
        utterance.rate = 1.0;
        break;
      case 'captain-america':
        utterance.pitch = 0.9;
        utterance.rate = 0.95;
        break;
      case 'doctor-strange':
        utterance.pitch = 0.88;
        utterance.rate = 0.92;
        break;
      default:
        utterance.pitch = 1.0;
        utterance.rate = 1.0;
    }

    utterance.onstart = () => {
      onStart?.();
    };

    utterance.onend = () => {
      onEnd?.();
    };

    utterance.onerror = () => {
      onEnd?.();
    };

    window.speechSynthesis.speak(utterance);
  }
}

export const soundEngine = new SoundEngine();
