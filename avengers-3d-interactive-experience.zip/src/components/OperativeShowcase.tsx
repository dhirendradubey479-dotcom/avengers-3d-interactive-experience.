import React, { useState, useEffect, useRef } from 'react';
import { Operative } from '../data/operatives';
import { soundEngine } from '../utils/audio';
import { Volume2, VolumeX, RotateCcw, Shield, Zap, Sparkles } from 'lucide-react';

interface OperativeShowcaseProps {
  operative: Operative;
  switchingStage: number; // 0: idle/ready, 1: exit, 2: palette shift, 3: materialize, 4: voice/telemetry
  isMuted: boolean;
  onToggleMute: () => void;
}

export const OperativeShowcase: React.FC<OperativeShowcaseProps> = ({
  operative,
  switchingStage,
  isMuted,
  onToggleMute,
}) => {
  const [rotate, setRotate] = useState({ x: 0, y: 0 });
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [currentValues, setCurrentValues] = useState<{ [key: string]: number }>({});
  const [imgSrc, setImgSrc] = useState(operative.image);
  const showcaseRef = useRef<HTMLDivElement>(null);

  // Update image when operative changes
  useEffect(() => {
    setImgSrc(operative.image);
  }, [operative]);

  // Handle 3D Parallax Tilt on the hero operative portrait
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!showcaseRef.current) return;
    const rect = showcaseRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotateY = ((x - centerX) / centerX) * 16;
    const rotateX = -((y - centerY) / centerY) * 16;
    setRotate({ x: rotateX, y: rotateY });
  };

  const handleMouseLeave = () => {
    setRotate({ x: 0, y: 0 });
  };

  // 7-Bar Power Analysis Calibration Engine
  useEffect(() => {
    if (switchingStage === 1) {
      // Step 01: Telemetry Exit - power gauges zero out
      setCurrentValues({
        strength: 0,
        agilitySpeed: 0,
        energyProjection: 0,
        durability: 0,
        intelligenceTech: 0,
        custom1: 0,
        custom2: 0,
      });
    } else if (switchingStage === 0 || switchingStage >= 3) {
      // Animate up to operative values
      const targetValues = {
        strength: operative.telemetry.strength,
        agilitySpeed: operative.telemetry.agilitySpeed,
        energyProjection: operative.telemetry.energyProjection,
        durability: operative.telemetry.durability,
        intelligenceTech: operative.telemetry.intelligenceTech,
        custom1: operative.telemetry.custom1Value,
        custom2: operative.telemetry.custom2Value,
      };

      // Animate values up smoothly
      let frame = 0;
      const totalFrames = 30;
      const interval = setInterval(() => {
        frame++;
        const progress = Math.min(1, frame / totalFrames);
        // Easing out cubic
        const ease = 1 - Math.pow(1 - progress, 3);

        setCurrentValues({
          strength: Math.round(targetValues.strength * ease),
          agilitySpeed: Math.round(targetValues.agilitySpeed * ease),
          energyProjection: Math.round(targetValues.energyProjection * ease),
          durability: Math.round(targetValues.durability * ease),
          intelligenceTech: Math.round(targetValues.intelligenceTech * ease),
          custom1: Math.round(targetValues.custom1 * ease),
          custom2: Math.round(targetValues.custom2 * ease),
        });

        if (progress >= 1) {
          clearInterval(interval);
        }
      }, 16);

      return () => clearInterval(interval);
    }
  }, [operative, switchingStage]);

  // Voice playback trigger
  const handleReplayVoice = () => {
    soundEngine.playClick(1600, 0.03);
    setIsSpeaking(true);
    soundEngine.speakDialogue(
      operative.voiceQuote,
      operative.id,
      () => setIsSpeaking(true),
      () => setIsSpeaking(false)
    );
  };

  const handleImageError = () => {
    if (imgSrc !== operative.referenceUrl) {
      setImgSrc(operative.referenceUrl);
    }
  };

  const metrics = [
    { label: 'Strength', key: 'strength', target: operative.telemetry.strength, isSourceLocked: true },
    { label: 'Agility & Speed', key: 'agilitySpeed', target: operative.telemetry.agilitySpeed, isSourceLocked: true },
    { label: 'Energy Projection', key: 'energyProjection', target: operative.telemetry.energyProjection, isSourceLocked: true },
    { label: 'Durability', key: 'durability', target: operative.telemetry.durability, isSourceLocked: true },
    { label: 'Intelligence / Tech', key: 'intelligenceTech', target: operative.telemetry.intelligenceTech, isSourceLocked: true },
    { label: operative.telemetry.custom1Name, key: 'custom1', target: operative.telemetry.custom1Value, isSourceLocked: false },
    { label: operative.telemetry.custom2Name, key: 'custom2', target: operative.telemetry.custom2Value, isSourceLocked: false },
  ];

  return (
    <div className="relative w-full rounded-2xl bg-slate-950/80 border border-slate-800/80 p-6 md:p-8 backdrop-blur-md overflow-hidden shadow-2xl">
      {/* Downward Scanline pass effect for Step 01 */}
      {switchingStage === 1 && (
        <div className="absolute inset-x-0 h-2 bg-cyan-400 shadow-[0_0_20px_#00d4ff] z-40 pointer-events-none animate-scanline" />
      )}

      {/* Subtle Background Glow Tint (Step 02 Palette Shift) */}
      <div
        className="absolute -top-32 -right-32 w-96 h-96 rounded-full pointer-events-none opacity-20 blur-3xl transition-colors duration-700"
        style={{ backgroundColor: operative.primaryColor }}
      />

      {/* Top Header Row of the Showcase */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <span
            className="text-xs font-mono-code font-bold px-2.5 py-1 rounded bg-slate-900 border text-slate-300"
            style={{ borderColor: operative.primaryColor }}
          >
            REF #{operative.number}
          </span>
          <div className="flex flex-col">
            <h2 className="font-cinzel text-xl md:text-2xl font-black text-white tracking-widest uppercase">
              {operative.name}
            </h2>
            <span className="text-xs text-slate-400 font-mono-code">
              {operative.identity}
            </span>
          </div>
        </div>

        {/* Controls: Mute, Replay Dialogue, Threat Level */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleMute}
            className={`p-2.5 rounded-lg border transition-colors flex items-center gap-1.5 text-xs font-mono-code cursor-pointer ${
              isMuted
                ? 'bg-red-950/40 border-red-800/60 text-red-300'
                : 'bg-slate-900 border-slate-700 text-cyan-300 hover:border-cyan-400'
            }`}
            title={isMuted ? 'Unmute Audio & Speech' : 'Mute Audio & Speech'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            <span className="hidden sm:inline">{isMuted ? 'MUTED' : 'AUDIO ON'}</span>
          </button>

          <button
            onClick={handleReplayVoice}
            disabled={isMuted}
            className={`px-3 py-2 rounded-lg border transition-colors flex items-center gap-2 text-xs font-mono-code cursor-pointer ${
              isSpeaking
                ? 'bg-cyan-500/20 border-cyan-400 text-white animate-pulse'
                : 'bg-slate-900 hover:bg-slate-800 border-slate-700 text-slate-200'
            } ${isMuted ? 'opacity-40 cursor-not-allowed' : ''}`}
          >
            <RotateCcw className={`w-3.5 h-3.5 ${isSpeaking ? 'animate-spin' : ''}`} />
            <span>REPLAY VOICE</span>
          </button>

          <div className="hidden lg:flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-800 text-xs font-mono-code">
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400">THREAT:</span>
            <span className="font-bold text-white tracking-wider">{operative.threatLevel}</span>
          </div>
        </div>
      </div>

      {/* Main 2-Column Content: Left 3D Anchor Image, Right 7-Bar Power Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-6">
        
        {/* Left Column: 3D Anchor Viewport Image with Holographic Tilt (Phase 3 & Step 03) */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div
            ref={showcaseRef}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            className="perspective-1000 w-full max-w-sm cursor-grab active:cursor-grabbing select-none"
          >
            <div
              className={`relative rounded-2xl p-2 border transition-all duration-300 transform-style-3d shadow-2xl ${
                switchingStage === 1 ? 'opacity-40 scale-95' : 'opacity-100 scale-100'
              }`}
              style={{
                borderColor: operative.primaryColor,
                boxShadow: `0 0 35px ${operative.glowColor}, inset 0 0 20px ${operative.glowColor}`,
                transform: `rotateX(${rotate.x}deg) rotateY(${rotate.y}deg)`,
              }}
            >
              {/* Tactical Holographic Corner Brackets */}
              <div
                className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2"
                style={{ borderColor: operative.accentColor }}
              />
              <div
                className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2"
                style={{ borderColor: operative.accentColor }}
              />
              <div
                className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2"
                style={{ borderColor: operative.accentColor }}
              />
              <div
                className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2"
                style={{ borderColor: operative.accentColor }}
              />

              {/* Exact Mapped Reference Image */}
              <div className="relative aspect-[3/4] w-full rounded-xl overflow-hidden bg-slate-900 border border-slate-700/60">
                <img
                  src={imgSrc}
                  alt={`${operative.name} tactical operative visual`}
                  referrerPolicy="no-referrer"
                  onError={handleImageError}
                  className="w-full h-full object-cover object-center transition-transform duration-500 hover:scale-105"
                />

                {/* Ambient vignette overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />

                {/* Holographic Scanlines Overlay */}
                <div className="absolute inset-0 pointer-events-none opacity-20 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.5)_50%)] bg-[length:100%_4px]" />

                {/* Bottom Operative Badge */}
                <div className="absolute bottom-3 inset-x-3 flex items-center justify-between text-[11px] font-mono-code text-slate-300 bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800">
                  <span className="flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5" style={{ color: operative.primaryColor }} />
                    <span>STATUS: ACTIVE</span>
                  </span>
                  <span className="text-slate-400">3D TILT ENABLED</span>
                </div>
              </div>
            </div>
          </div>

          {/* Voice Dialogue Speech Bubble with Live Web Speech API */}
          <div className="w-full max-w-sm mt-4 p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-md">
            <div className="flex items-center justify-between text-xs font-mono-code text-slate-400 mb-1.5">
              <span className="flex items-center gap-1.5 text-cyan-300">
                <Sparkles className="w-3 h-3" />
                <span>SYNTHESIZED DIALOGUE</span>
              </span>
              {isSpeaking && (
                <span className="flex gap-1 items-center">
                  <span className="w-1.5 h-3 bg-cyan-400 animate-pulse" />
                  <span className="w-1.5 h-4 bg-cyan-400 animate-pulse delay-75" />
                  <span className="w-1.5 h-2 bg-cyan-400 animate-pulse delay-150" />
                </span>
              )}
            </div>
            <p className="text-sm font-semibold italic text-white tracking-wide">
              &ldquo;{operative.voiceQuote}&rdquo;
            </p>
          </div>
        </div>

        {/* Right Column: 7-Bar Power Analysis Engine & Tactical Loadout */}
        <div className="lg:col-span-7 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: operative.primaryColor }} />
                <h3 className="font-cinzel text-lg font-bold tracking-wider text-white">
                  7-Bar Power Telemetry Engine
                </h3>
              </div>
              <span className="text-xs font-mono-code text-slate-400">
                CALIBRATION // NOMINAL
              </span>
            </div>

            {/* 7-Bar Gauges */}
            <div className="space-y-3.5 bg-slate-900/60 p-4 md:p-5 rounded-xl border border-slate-800">
              {metrics.map((metric) => {
                const val = currentValues[metric.key] ?? 0;
                return (
                  <div key={metric.key} className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-mono-code">
                      <span className="text-slate-300 font-medium tracking-wide">
                        {metric.label}
                      </span>
                      <div className="flex items-center gap-2">
                        {metric.isSourceLocked && (
                          <span className="text-[10px] text-slate-500 font-mono-code hidden sm:inline">
                            [SOURCE LOCK]
                          </span>
                        )}
                        <span
                          className="font-bold text-sm tracking-wider font-mono-code"
                          style={{ color: operative.primaryColor }}
                        >
                          {val}%
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar Container */}
                    <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
                      <div
                        className="h-full rounded-full transition-all duration-300 relative shadow-sm"
                        style={{
                          width: `${val}%`,
                          backgroundColor: operative.primaryColor,
                          boxShadow: `0 0 10px ${operative.primaryColor}`,
                        }}
                      >
                        <div className="absolute right-0 top-0 bottom-0 w-2 bg-white/70 rounded-full" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Character Environment & Combat Loadout */}
          <div className="mt-6 pt-6 border-t border-slate-800 space-y-4">
            <div>
              <span className="text-[11px] font-mono-code tracking-widest text-slate-400 block mb-1">
                COMBAT ENVIRONMENT & SIGNATURE EFFECT
              </span>
              <div
                className="p-3 rounded-lg border text-xs font-mono-code text-slate-200 bg-slate-900/80"
                style={{ borderColor: `${operative.primaryColor}55` }}
              >
                {operative.environment}
              </div>
            </div>

            <div>
              <span className="text-[11px] font-mono-code tracking-widest text-slate-400 block mb-2">
                DEPLOYABLE COMBAT LOADOUT
              </span>
              <div className="flex flex-wrap gap-2">
                {operative.loadout.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-900 border border-slate-700/80 text-xs font-mono-code text-white"
                  >
                    <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: operative.primaryColor }} />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Dossier Bio */}
            <div>
              <span className="text-[11px] font-mono-code tracking-widest text-slate-400 block mb-1">
                TACTICAL DOSSIER BRIEFING
              </span>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                {operative.bio}
              </p>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
