import React, { useEffect, useState, useRef } from 'react';
import { soundEngine } from '../utils/audio';

interface CinematicBootProps {
  onComplete: () => void;
}

export const CinematicBoot: React.FC<CinematicBootProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [bootPhase, setBootPhase] = useState('INITIALIZING SECURE PROTOCOL');
  const [mouseOffset, setMouseOffset] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Parallax tracking
    const handleMouseMove = (e: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      const x = (e.clientX / innerWidth - 0.5) * 24;
      const y = (e.clientY / innerHeight - 0.5) * 24;
      setMouseOffset({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    let current = 0;
    const interval = setInterval(() => {
      // Non-linear progress curve mimicking high-speed system diagnostics
      const step = current < 30 ? 1.8 : current < 70 ? 2.8 : current < 95 ? 2.0 : 1.2;
      current += step;

      if (current >= 100) {
        current = 100;
        setProgress(100);
        setBootPhase('AVENGERS DEFENSE PROTOCOL ONLINE');
        soundEngine.startBootHum(100);
        soundEngine.playRecalibrationSweep(1.2);
        clearInterval(interval);
        setTimeout(() => {
          soundEngine.stopBootHum();
          onComplete();
        }, 650);
      } else {
        setProgress(Math.floor(current));
        soundEngine.startBootHum(current);

        if (current < 25) {
          setBootPhase('CONNECTING STARK SATELLITE NETWORK...');
        } else if (current < 50) {
          setBootPhase('CALIBRATING TACTICAL HOLO-PROJECTION...');
        } else if (current < 75) {
          setBootPhase('RETRIEVING 9 CLASSIFIED DOSSIERS...');
        } else {
          setBootPhase('SYNCHRONIZING OPERATIVE TELEMETRY MATRIX...');
        }
      }
    }, 45);

    return () => {
      clearInterval(interval);
      soundEngine.stopBootHum();
    };
  }, [onComplete]);

  const handleBypass = () => {
    soundEngine.stopBootHum();
    soundEngine.playClick(1500, 0.05);
    onComplete();
  };

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#020617] text-cyan-400 select-none overflow-hidden"
    >
      {/* Dynamic Cybernetic Perspective Grid Background */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          transform: `perspective(800px) rotateX(${25 + mouseOffset.y * 0.3}deg) rotateY(${mouseOffset.x * 0.3}deg) translateY(-20px)`,
          backgroundImage: `
            linear-gradient(to right, rgba(0, 212, 255, 0.35) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(0, 212, 255, 0.35) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
        }}
      />

      {/* Dynamic radial ambient flare */}
      <div
        className="absolute w-[600px] h-[600px] rounded-full pointer-events-none transition-all duration-300 blur-3xl opacity-25"
        style={{
          background: 'radial-gradient(circle, #00d4ff 0%, #3b82f6 40%, transparent 70%)',
          transform: `translate(${mouseOffset.x * 2}px, ${mouseOffset.y * 2}px)`,
        }}
      />

      {/* Top HUD Security Badge */}
      <div className="absolute top-8 left-8 flex items-center gap-3 text-xs tracking-[0.25em] text-slate-400 font-mono-code">
        <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
        <span>SHIELD // TACTICAL COMMAND NODE 09</span>
      </div>

      <button
        onClick={handleBypass}
        className="absolute top-8 right-8 px-4 py-2 text-xs font-mono-code tracking-widest text-cyan-300 border border-cyan-500/40 rounded bg-cyan-950/40 hover:bg-cyan-900/60 hover:border-cyan-400 transition-all cursor-pointer backdrop-blur-sm"
      >
        BYPASS BOOT [ESC]
      </button>

      {/* 3D Holographic Arc Core */}
      <div
        className="relative w-72 h-72 md:w-96 md:h-96 flex items-center justify-center perspective-1000 mb-8"
        style={{
          transform: `rotateY(${mouseOffset.x}deg) rotateX(${-mouseOffset.y}deg)`,
        }}
      >
        {/* Outer Ring 1 */}
        <div className="absolute inset-0 rounded-full border border-cyan-500/30 border-dashed animate-spin-slow" />
        
        {/* Outer Ring 2 - Reverse */}
        <div className="absolute inset-4 rounded-full border border-sky-400/40 border-t-transparent animate-spin-reverse" />

        {/* Outer Ring 3 - Fast Accent */}
        <div className="absolute inset-10 rounded-full border-2 border-cyan-400/20 border-b-cyan-400/80 animate-spin-slow" />

        {/* 3D Wireframe Hexagonal Core */}
        <div className="relative w-44 h-44 md:w-56 md:h-56 flex items-center justify-center">
          <svg className="w-full h-full" viewBox="0 0 200 200">
            {/* Hexagon wireframe */}
            <polygon
              points="100,20 170,60 170,140 100,180 30,140 30,60"
              fill="rgba(0, 212, 255, 0.05)"
              stroke="#00d4ff"
              strokeWidth="2"
              className="drop-shadow-[0_0_12px_rgba(0,212,255,0.7)]"
            />
            {/* Inner concentric hex */}
            <polygon
              points="100,45 150,75 150,125 100,155 50,125 50,75"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="1.5"
              strokeDasharray="6,4"
              opacity="0.8"
            />
            {/* Crosshair rays */}
            <line x1="100" y1="10" x2="100" y2="190" stroke="#38bdf8" strokeWidth="1" strokeDasharray="4,8" opacity="0.6"/>
            <line x1="10" y1="100" x2="190" y2="100" stroke="#38bdf8" strokeWidth="1" strokeDasharray="4,8" opacity="0.6"/>
            {/* Center Core node */}
            <circle cx="100" cy="100" r="16" fill="#e0f2fe" className="drop-shadow-[0_0_20px_#38bdf8]"/>
            <circle cx="100" cy="100" r="6" fill="#0284c7" />
          </svg>

          {/* Central Percentage Display */}
          <div className="absolute flex flex-col items-center">
            <span className="text-3xl md:text-4xl font-mono-code font-bold text-white drop-shadow-[0_0_10px_#00d4ff]">
              {progress}%
            </span>
            <span className="text-[10px] font-mono-code tracking-[0.3em] text-cyan-300">
              POWER SURGE
            </span>
          </div>
        </div>

        {/* Dynamic Light Sweep Bar */}
        <div
          className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-75 blur-xs"
          style={{
            top: `${(progress % 100)}%`,
            transition: 'top 0.05s linear',
          }}
        />
      </div>

      {/* Main Title & Phase Status */}
      <div className="flex flex-col items-center text-center max-w-xl px-4 z-10">
        <h1 className="font-cinzel text-2xl md:text-3xl font-extrabold tracking-[0.25em] text-white uppercase drop-shadow-[0_0_15px_rgba(0,212,255,0.6)] mb-2">
          Avengers 3D Experience
        </h1>
        <p className="font-mono-code text-xs md:text-sm text-cyan-300/80 tracking-widest uppercase h-6">
          {bootPhase}
        </p>

        {/* Horizontal HUD Power Surge Progress Bar */}
        <div className="w-72 md:w-96 h-2 bg-slate-900 border border-cyan-500/40 rounded-full mt-6 p-0.5 overflow-hidden shadow-[0_0_15px_rgba(0,212,255,0.2)]">
          <div
            className="h-full bg-gradient-to-r from-blue-600 via-cyan-400 to-white rounded-full transition-all duration-75 relative shadow-[0_0_10px_#00d4ff]"
            style={{ width: `${progress}%` }}
          >
            <div className="absolute right-0 top-0 bottom-0 w-2 bg-white blur-xs" />
          </div>
        </div>

        {/* Micro Telemetry Indicators */}
        <div className="flex items-center gap-6 mt-6 text-[10px] font-mono-code text-slate-500 tracking-widest">
          <span>SEC // LEVEL 10</span>
          <span>·</span>
          <span>SYS // NOMINAL</span>
          <span>·</span>
          <span>FPS // 60 TARGET</span>
        </div>
      </div>
    </div>
  );
};
