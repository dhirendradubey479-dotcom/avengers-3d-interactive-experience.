import React, { useState, useRef } from 'react';
import { Operative } from '../data/operatives';
import { soundEngine } from '../utils/audio';

interface OperativeCardProps {
  operative: Operative;
  isActive: boolean;
  onSelect: (operative: Operative) => void;
}

export const OperativeCard: React.FC<OperativeCardProps> = ({
  operative,
  isActive,
  onSelect,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotate, setRotate] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const [imgSrc, setImgSrc] = useState(operative.image);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    // Calculate 3D tilt degrees
    const rotateY = ((x - centerX) / centerX) * 14;
    const rotateX = -((y - centerY) / centerY) * 14;
    setRotate({ x: rotateX, y: rotateY });
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
    soundEngine.playClick(1400, 0.02);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotate({ x: 0, y: 0 });
  };

  const handleClick = () => {
    soundEngine.playClick(1800, 0.04);
    onSelect(operative);
  };

  const handleImageError = () => {
    // If the local file fails, fall back to referenceUrl, or vice-versa
    if (imgSrc !== operative.referenceUrl) {
      setImgSrc(operative.referenceUrl);
    }
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={handleClick}
      className="perspective-1000 cursor-pointer select-none group"
      style={{ minHeight: '135px' }}
    >
      <div
        className={`relative w-full h-full rounded-xl p-3 border transition-all duration-200 transform-style-3d overflow-hidden ${
          isActive
            ? 'bg-slate-900/90 shadow-lg'
            : 'bg-slate-950/60 hover:bg-slate-900/70 border-slate-800/80 hover:border-slate-700'
        }`}
        style={{
          borderColor: isActive ? operative.primaryColor : undefined,
          boxShadow: isActive ? `0 0 24px ${operative.glowColor}, inset 0 0 12px ${operative.glowColor}` : undefined,
          transform: isHovered
            ? `rotateX(${rotate.x}deg) rotateY(${rotate.y}deg) scale3d(1.03, 1.03, 1.03)`
            : 'rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)',
        }}
      >
        {/* Holographic scanline sheen on active/hover */}
        {(isActive || isHovered) && (
          <div
            className="absolute inset-0 pointer-events-none opacity-20 bg-gradient-to-b from-transparent via-white to-transparent -translate-y-full group-hover:translate-y-full transition-transform duration-1000 ease-in-out"
          />
        )}

        {/* Tactical Corner Brackets */}
        <div
          className="absolute top-1.5 left-1.5 w-2 h-2 border-t-2 border-l-2 transition-colors duration-200"
          style={{ borderColor: isActive ? operative.primaryColor : 'rgba(148, 163, 184, 0.4)' }}
        />
        <div
          className="absolute top-1.5 right-1.5 w-2 h-2 border-t-2 border-r-2 transition-colors duration-200"
          style={{ borderColor: isActive ? operative.primaryColor : 'rgba(148, 163, 184, 0.4)' }}
        />
        <div
          className="absolute bottom-1.5 left-1.5 w-2 h-2 border-b-2 border-l-2 transition-colors duration-200"
          style={{ borderColor: isActive ? operative.primaryColor : 'rgba(148, 163, 184, 0.4)' }}
        />
        <div
          className="absolute bottom-1.5 right-1.5 w-2 h-2 border-b-2 border-r-2 transition-colors duration-200"
          style={{ borderColor: isActive ? operative.primaryColor : 'rgba(148, 163, 184, 0.4)' }}
        />

        <div className="flex items-center gap-3">
          {/* Operative Exact Reference Image Thumbnail */}
          <div className="relative w-16 h-20 md:w-20 md:h-24 rounded-lg overflow-hidden shrink-0 border border-slate-700/80 bg-slate-900">
            <img
              src={imgSrc}
              alt={operative.name}
              referrerPolicy="no-referrer"
              onError={handleImageError}
              className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-500"
            />
            {/* Active badge overlay indicator */}
            {isActive && (
              <div
                className="absolute inset-0 border-2 pointer-events-none"
                style={{ borderColor: operative.primaryColor }}
              />
            )}
            <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 to-transparent p-1 text-center">
              <span className="text-[10px] font-mono-code text-white tracking-widest">
                {operative.number}
              </span>
            </div>
          </div>

          {/* Operative Info */}
          <div className="flex flex-col min-w-0 flex-1">
            <div className="flex items-center justify-between gap-1 mb-1">
              <span
                className="text-[10px] font-mono-code font-bold tracking-widest uppercase truncate"
                style={{ color: isActive ? operative.primaryColor : '#94a3b8' }}
              >
                {operative.classification}
              </span>
              {isActive && (
                <span className="w-2 h-2 rounded-full animate-ping shrink-0" style={{ backgroundColor: operative.primaryColor }} />
              )}
            </div>

            <h3 className="font-cinzel text-sm md:text-base font-bold text-white tracking-wide truncate group-hover:text-cyan-200 transition-colors">
              {operative.name}
            </h3>

            <p className="text-[11px] text-slate-400 font-mono-code truncate mt-0.5">
              {operative.identity}
            </p>

            {/* Micro power indicator preview */}
            <div className="flex items-center gap-2 mt-2">
              <div className="flex-1 h-1 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-300"
                  style={{
                    width: `${operative.telemetry.strength}%`,
                    backgroundColor: operative.primaryColor,
                  }}
                />
              </div>
              <span className="text-[10px] font-mono-code text-slate-400">
                {operative.telemetry.strength}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
