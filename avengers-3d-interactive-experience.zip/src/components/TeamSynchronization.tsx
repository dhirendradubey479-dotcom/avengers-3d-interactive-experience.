import React, { useState, useEffect } from 'react';
import { OPERATIVES, Operative } from '../data/operatives';
import { soundEngine } from '../utils/audio';
import { Zap, Shield, Play, RotateCcw } from 'lucide-react';

interface TeamSynchronizationProps {
  onSelectOperative: (operative: Operative) => void;
  onClose?: () => void;
}

export const TeamSynchronization: React.FC<TeamSynchronizationProps> = ({
  onSelectOperative,
}) => {
  const [isAssembling, setIsAssembling] = useState(false);
  const [showTitleCard, setShowTitleCard] = useState(false);
  const [reactorPower, setReactorPower] = useState(78);
  const [activeNodeIndex, setActiveNodeIndex] = useState<number | null>(null);

  // Auto-pulse reactor power gently when idle
  useEffect(() => {
    if (isAssembling) return;
    const interval = setInterval(() => {
      setReactorPower(prev => 75 + Math.floor(Math.sin(Date.now() / 800) * 8));
    }, 400);
    return () => clearInterval(interval);
  }, [isAssembling]);

  const handleInitiateSync = () => {
    if (isAssembling) return;
    setIsAssembling(true);
    soundEngine.playReactorPulse();
    soundEngine.playAssembleCrescendo();

    // Surge reactor power
    let p = reactorPower;
    const surgeInterval = setInterval(() => {
      p += 4;
      if (p >= 100) {
        p = 100;
        setReactorPower(100);
        clearInterval(surgeInterval);

        // Climax title card
        setTimeout(() => {
          setShowTitleCard(true);
          soundEngine.speakDialogue('Avengers... Assemble!', 'captain-america');
        }, 1100);
      } else {
        setReactorPower(p);
      }
    }, 40);
  };

  const handleResetSync = () => {
    setIsAssembling(false);
    setShowTitleCard(false);
    setReactorPower(78);
    soundEngine.playClick(1000, 0.04);
  };

  // 9 circular nodes coordinate math (circle radius 220px on 600x600 viewBox)
  const center = 300;
  const radius = 220;
  const nodes = OPERATIVES.map((op, idx) => {
    const angle = (idx * (360 / 9) - 90) * (Math.PI / 180);
    const x = center + radius * Math.cos(angle);
    const y = center + radius * Math.sin(angle);
    return { ...op, x, y, angleDeg: idx * (360 / 9) - 90 };
  });

  return (
    <div className="relative w-full rounded-2xl bg-[#020617]/95 border border-slate-800 p-6 md:p-8 backdrop-blur-xl overflow-hidden shadow-2xl">
      {/* Global Ambient Darkening & Energy Flash when Assembling */}
      {isAssembling && (
        <div className="absolute inset-0 bg-black/60 pointer-events-none z-10 transition-opacity duration-1000" />
      )}

      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-800 z-20 relative">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-cyan-400 animate-ping" />
          <div>
            <h2 className="font-cinzel text-xl md:text-2xl font-black text-white tracking-widest uppercase">
              Phase 7 // Team Synchronization Matrix
            </h2>
            <p className="text-xs text-slate-400 font-mono-code">
              9-Node Synapse Grid & Stark Arc Reactor Core
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {!isAssembling ? (
            <button
              onClick={handleInitiateSync}
              className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold font-mono-code text-xs tracking-widest transition-all shadow-[0_0_20px_rgba(0,212,255,0.4)] flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>INITIATE TEAM SYNC</span>
            </button>
          ) : (
            <button
              onClick={handleResetSync}
              className="px-4 py-2 rounded-lg bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-200 font-mono-code text-xs tracking-wider transition-colors flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>RESET FORMATION</span>
            </button>
          )}
        </div>
      </div>

      {/* Central Interactive 9-Node Synapse Grid (SVG + Interactive Elements) */}
      <div className="relative w-full max-w-3xl mx-auto aspect-square my-8 flex items-center justify-center select-none">
        
        {/* SVG Energy Conduits & Synapse Lines */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 600 600"
          preserveAspectRatio="xMidYMid meet"
        >
          <defs>
            <filter id="conduitGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            {/* Radial gradient for central reactor aura */}
            <radialGradient id="reactorAura" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="#38bdf8" stop-opacity="0.8" />
              <stop offset="50%" stop-color="#0284c7" stop-opacity="0.3" />
              <stop offset="100%" stop-color="transparent" stop-opacity="0" />
            </radialGradient>
          </defs>

          {/* Outer Synapse Perimeter Ring */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="none"
            stroke="rgba(56, 189, 248, 0.2)"
            strokeWidth="1.5"
            strokeDasharray="8,6"
          />

          {/* Secondary Concentric Radar Ring */}
          <circle
            cx={center}
            cy={center}
            r={130}
            fill="none"
            stroke="rgba(56, 189, 248, 0.15)"
            strokeWidth="1"
          />

          {/* Dynamic Energy Conduits linking every operative to Stark Arc Reactor */}
          {nodes.map((node, i) => (
            <g key={i}>
              {/* Static base wire */}
              <line
                x1={center}
                y1={center}
                x2={node.x}
                y2={node.y}
                stroke={node.primaryColor}
                strokeWidth={isAssembling ? 3 : 1.5}
                strokeOpacity={isAssembling ? 0.9 : 0.4}
                filter="url(#conduitGlow)"
              />
              {/* Pulsating energy flow packet */}
              <line
                x1={center}
                y1={center}
                x2={node.x}
                y2={node.y}
                stroke="#ffffff"
                strokeWidth={isAssembling ? 4 : 2}
                strokeDasharray="12,30"
                className="animate-energy-pulse"
                opacity={isAssembling ? 0.9 : 0.6}
              />
            </g>
          ))}

          {/* Central Reactor Glow Halo */}
          <circle
            cx={center}
            cy={center}
            r={isAssembling ? 120 : 85}
            fill="url(#reactorAura)"
            className="transition-all duration-700"
          />
        </svg>

        {/* Central Stark Arc Reactor Core */}
        <div
          onClick={handleInitiateSync}
          className="relative z-20 w-36 h-36 md:w-44 md:h-44 rounded-full flex flex-col items-center justify-center cursor-pointer group"
          title="Stark Mark L Arc Reactor Core - Click to Synchronize"
        >
          {/* Rotating Outer Reactor Brackets */}
          <div className="absolute inset-0 rounded-full border-2 border-cyan-400/40 border-dashed animate-spin-slow" />
          <div className="absolute inset-2 rounded-full border border-sky-300/50 border-t-transparent animate-spin-reverse" />
          
          {/* Central Core Glass & Coil Housing */}
          <div
            className={`w-28 h-28 md:w-32 md:h-32 rounded-full flex flex-col items-center justify-center border-2 transition-all duration-500 backdrop-blur-md ${
              isAssembling
                ? 'bg-cyan-950/80 border-cyan-300 shadow-[0_0_40px_#00d4ff]'
                : 'bg-slate-950/90 border-cyan-500/60 shadow-[0_0_20px_rgba(0,212,255,0.4)] group-hover:border-cyan-300'
            }`}
          >
            {/* Palladium Triangle Emblem */}
            <div className="relative w-12 h-12 flex items-center justify-center">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                <polygon
                  points="50,15 90,85 10,85"
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="6"
                  className={isAssembling ? 'drop-shadow-[0_0_12px_#38bdf8]' : ''}
                />
                <circle cx="50" cy="60" r="14" fill="#e0f2fe" className="drop-shadow-[0_0_10px_#ffffff]" />
              </svg>
            </div>

            <span className="text-xs font-mono-code font-bold text-white tracking-widest mt-1">
              {reactorPower}%
            </span>
            <span className="text-[9px] font-mono-code tracking-[0.2em] text-cyan-300">
              ARC REACTOR
            </span>
          </div>
        </div>

        {/* 9 Circular Operative Nodes along the perimeter */}
        {nodes.map((node, idx) => {
          // Calculate percentages for CSS absolute positioning relative to container
          const leftPercent = ((node.x) / 600) * 100;
          const topPercent = ((node.y) / 600) * 100;
          const isCurrentActive = activeNodeIndex === idx;

          return (
            <div
              key={node.id}
              onClick={() => {
                setActiveNodeIndex(idx);
                onSelectOperative(node);
                soundEngine.playClick(1500, 0.03);
              }}
              className="absolute z-20 -translate-x-1/2 -translate-y-1/2 group cursor-pointer"
              style={{
                left: `${leftPercent}%`,
                top: `${topPercent}%`,
              }}
            >
              <div
                className={`relative w-14 h-14 md:w-18 md:h-18 rounded-full p-1 border-2 transition-all duration-300 flex items-center justify-center ${
                  isAssembling
                    ? 'scale-110 shadow-[0_0_25px_var(--glow)]'
                    : 'hover:scale-115'
                } ${isCurrentActive ? 'ring-2 ring-white scale-120' : ''}`}
                style={{
                  borderColor: node.primaryColor,
                  backgroundColor: '#030712',
                  ['--glow' as string]: node.primaryColor,
                  boxShadow: isAssembling
                    ? `0 0 25px ${node.primaryColor}, inset 0 0 10px ${node.primaryColor}`
                    : `0 0 12px ${node.glowColor}`,
                }}
              >
                {/* Operative Thumbnail */}
                <div className="w-full h-full rounded-full overflow-hidden">
                  <img
                    src={node.image}
                    alt={node.name}
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = node.referenceUrl;
                    }}
                    className="w-full h-full object-cover object-center"
                  />
                </div>

                {/* Badge Number */}
                <div className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-full bg-slate-900 border border-slate-700 text-[9px] font-mono-code text-white">
                  {node.number}
                </div>

                {/* Tooltip Hover Tag */}
                <div className="absolute -top-7 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded bg-slate-900/95 border border-slate-700 text-[10px] font-mono-code text-white whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-lg">
                  {node.name}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* CLIMAX TITLE CARD: "AVENGERS ASSEMBLE" (Phase 7 Climax) */}
      {showTitleCard && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/90 backdrop-blur-2xl p-6 select-none animate-in fade-in zoom-in duration-500">
          {/* Heroic Shockwave Pulse Rings */}
          <div className="absolute w-[600px] h-[600px] rounded-full border-2 border-cyan-400/40 animate-ping pointer-events-none" />
          <div className="absolute w-[450px] h-[450px] rounded-full border-2 border-amber-400/30 animate-pulse pointer-events-none" />

          {/* Master Title Card */}
          <div className="relative text-center max-w-2xl px-6 py-10 rounded-3xl bg-slate-950/90 border-2 border-cyan-400 shadow-[0_0_80px_rgba(0,212,255,0.6)]">
            <span className="text-xs md:text-sm font-mono-code font-bold tracking-[0.4em] text-cyan-400 uppercase block mb-3">
              ALL 9 OPERATIVES ENGAGED · BATTLE FORMATION ALPHA
            </span>

            <h1 className="font-cinzel text-4xl sm:text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-200 to-amber-300 tracking-[0.2em] uppercase drop-shadow-[0_0_30px_rgba(255,255,255,0.8)]">
              AVENGERS ASSEMBLE
            </h1>

            <p className="mt-4 text-sm md:text-base font-mono-code text-slate-300 italic tracking-wider">
              &ldquo;Whatever it takes. Earth&apos;s Mightiest Heroes united against any cosmic threat.&rdquo;
            </p>

            {/* 9 Battle Formation Hero Badges */}
            <div className="flex flex-wrap items-center justify-center gap-3 mt-8">
              {OPERATIVES.map((op) => (
                <div
                  key={op.id}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-mono-code text-white bg-slate-900/90"
                  style={{ borderColor: op.primaryColor }}
                >
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: op.primaryColor }} />
                  <span>{op.name}</span>
                </div>
              ))}
            </div>

            {/* Return / Dismiss Button */}
            <div className="mt-8 flex justify-center">
              <button
                onClick={() => setShowTitleCard(false)}
                className="px-8 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold font-mono-code text-xs tracking-widest transition-all shadow-[0_0_20px_rgba(0,212,255,0.4)] cursor-pointer"
              >
                RETURN TO TACTICAL COMMAND
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer Info bar */}
      <div className="flex flex-wrap items-center justify-between text-xs font-mono-code text-slate-400 pt-4 border-t border-slate-800">
        <span className="flex items-center gap-2">
          <Zap className="w-3.5 h-3.5 text-cyan-400" />
          <span>CONDUIT STATUS: 9/9 ENERGIZED</span>
        </span>
        <span className="text-slate-500 hidden sm:inline">
          CLICK ANY OPERATIVE NODE TO INSPECT TELEMETRY
        </span>
        <span className="flex items-center gap-1.5 text-slate-300">
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          <span>ALLIANCE LEVEL: MAXIMUM</span>
        </span>
      </div>
    </div>
  );
};
