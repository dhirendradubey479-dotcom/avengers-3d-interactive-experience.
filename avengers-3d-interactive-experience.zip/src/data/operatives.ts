export interface TelemetryMetric {
  name: string;
  value: number;
  description?: string;
}

export interface Operative {
  id: string;
  number: string;
  name: string;
  identity: string;
  sourceFile: string;
  image: string;
  referenceUrl: string;
  environment: string;
  loadout: string[];
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  glowColor: string;
  bgGradient: string;
  voiceQuote: string;
  alternateQuote: string;
  telemetry: {
    strength: number;
    agilitySpeed: number;
    energyProjection: number;
    durability: number;
    intelligenceTech: number;
    custom1Name: string;
    custom1Value: number;
    custom2Name: string;
    custom2Value: number;
  };
  classification: string;
  threatLevel: string;
  bio: string;
}

export const OPERATIVES: Operative[] = [
  {
    id: 'thor',
    number: '01',
    name: 'THOR',
    identity: 'God of Thunder // Asgard',
    sourceFile: 'thor.jpg',
    image: '/thor.jpg',
    referenceUrl: 'https://lh3.googleusercontent.com/gg/AJWXcNdFpnzB9g8SbOGnmruifsJuNI2fL7cGZBpc66TV10vrtA5iECq_vHd0lyDOJvcL1Bgdn12DtYTrOTMbGtx5D93LBYLwYwEwNeFvOz7-nfMdy7M7of95MAjxMPBBfl3l5UwzhbJUORxu19m8ADeZEmmEwYwhBUwOjxJkWatxpC0A13DQbnl3SUTLEB_oMHA4z3cTMfPmlckb_xJ_zYSDWyWSz-9_gdDkzBxWOcjE99jg4cfJe51N6pPto1d2xZUVB_bnt0nPodTo2HnUbS02Jfedd9_6S-bBQ=s0',
    environment: 'Storm, lightning discharge, blue/cyan aura',
    loadout: ['Mjolnir', 'Stormbreaker', 'Lightning Channel'],
    primaryColor: '#00d4ff',
    secondaryColor: '#1e3a8a',
    accentColor: '#38bdf8',
    glowColor: 'rgba(0, 212, 255, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 30%, rgba(0, 212, 255, 0.18) 0%, rgba(15, 23, 42, 0.95) 75%, #030712 100%)',
    voiceQuote: 'I am Thor',
    alternateQuote: 'Whosoever holds this hammer, if he be worthy, shall possess the power of Thor.',
    telemetry: {
      strength: 98,
      agilitySpeed: 88,
      energyProjection: 99,
      durability: 97,
      intelligenceTech: 80,
      custom1Name: 'Divine Resonance',
      custom1Value: 100,
      custom2Name: 'Bifrost Conduit',
      custom2Value: 95,
    },
    classification: 'COSMIC DEMIGOD',
    threatLevel: 'OMEGA-LEVEL',
    bio: 'Crown Prince of Asgard and master of cosmic lightning storms. Wields the uru-forged weapons Mjolnir and Stormbreaker to summon planetary thunder strikes and traverse the realms via the Bifrost bridge.'
  },
  {
    id: 'black-panther',
    number: '02',
    name: 'BLACK PANTHER',
    identity: "King T'Challa // Wakanda",
    sourceFile: 'black-panther.jpg',
    image: '/black-panther.jpg',
    referenceUrl: 'https://lh3.googleusercontent.com/gg/AJWXcNfrhAT-8d-PGBqES-t0JeuhYlnTjp9k6QUzTGsfCV_YOUsJPbVbjBk2_qegimV21G0CTnXzUJz-aKbhNaRb0_Z2bxCbEwabyJ8Fi8R8LhSf-Lh0qi4IGFIhCp6rRbvLY-hGS_TB755j4YKQW0DVxq9VAwWBVFrwgOHKQLGi9DEleeTk4dRD7H-CiMfOB6255_h6XhW9__mxjT0nnFHdGZX-QGUdw7EZZ1LKZO-0levBvpbrZN_7KbJDLdxiHyNelp-FcgeSaH3l2ZlQqaed51hsUGnHPyIZ=s0',
    environment: 'Wakandan tech, kinetic violet pulses',
    loadout: ['Vibranium Claws', 'Kinetic Shock Suit', 'Heart-Shaped Herb Aura'],
    primaryColor: '#c084fc',
    secondaryColor: '#581c87',
    accentColor: '#e879f9',
    glowColor: 'rgba(192, 132, 252, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 30%, rgba(192, 132, 252, 0.16) 0%, rgba(20, 10, 35, 0.95) 75%, #030712 100%)',
    voiceQuote: 'I am Black Panther',
    alternateQuote: 'In my culture, death is not the end. It is more of a stepping-off point.',
    telemetry: {
      strength: 82,
      agilitySpeed: 96,
      energyProjection: 78,
      durability: 91,
      intelligenceTech: 94,
      custom1Name: 'Kinetic Absorption',
      custom1Value: 99,
      custom2Name: 'Tactical Leadership',
      custom2Value: 98,
    },
    classification: 'SOVEREIGN PROTECTOR',
    threatLevel: 'ALPHA-STRATEGIC',
    bio: 'Monarch of Wakanda imbued with superhuman agility by the Sacred Heart-Shaped Herb. Encased in a nanotech vibranium weave that redistributes kinetic energy impacts as explosive concussive shockwaves.'
  },
  {
    id: 'black-widow',
    number: '03',
    name: 'BLACK WIDOW',
    identity: 'Natasha Romanoff // Espionage',
    sourceFile: 'black-widow.jpg',
    image: '/black-widow.jpg',
    referenceUrl: 'https://lh3.googleusercontent.com/gg/AJWXcNcDdwsDKLDUNLXyj35LYX5ONLODdAlLAP5qSHyGrBcMcqQCFYofSlRb2ulNUSwO0DUl-52iX8F9Q6PiFbJ_USeqkWHYh23n8IY_TqcwwMG0iaVuOZA_ZwiaEz7RyQwcppnRz669QLqj1v5XhXQ7bx-P5AIVbOANfxYr2F9C1M_o8dfwSNP30IbRjArc53kGO9gAfocLOGqPxghWgjb216TvYCoeybsnwD_H6e3EsXUqiSrkknN6xqVjFrxi4iHBmZL8YxeoTQvO4oYiOgPRvvLRsuWkt7F3w=s0',
    environment: 'Tactical white/crimson hourglass',
    loadout: ["Electro-Shock Batons", "Widow's Bite", "Dual Gliders"],
    primaryColor: '#ef4444',
    secondaryColor: '#881337',
    accentColor: '#f87171',
    glowColor: 'rgba(239, 68, 68, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 30%, rgba(239, 68, 68, 0.16) 0%, rgba(25, 10, 15, 0.95) 75%, #030712 100%)',
    voiceQuote: 'I am Black Widow',
    alternateQuote: 'I get emails from a raccoon, so nothing sounds crazy anymore.',
    telemetry: {
      strength: 45,
      agilitySpeed: 97,
      energyProjection: 35,
      durability: 50,
      intelligenceTech: 90,
      custom1Name: 'Covert Infiltration',
      custom1Value: 100,
      custom2Name: 'CQC Master Specialist',
      custom2Value: 97,
    },
    classification: 'SPECIAL OPERATIONS',
    threatLevel: 'TACTICAL-LETHAL',
    bio: 'Premier espionage operative and elite assassin of the Red Room program turned key Avengers strategist. Lethal in close-quarters combat with high-voltage electro-shock batons and micro-munition wrist gauntlets.'
  },
  {
    id: 'spider-man',
    number: '04',
    name: 'SPIDER-MAN',
    identity: 'Peter Parker // Queens',
    sourceFile: 'spider-man.jpg',
    image: '/spider-man.jpg',
    referenceUrl: 'https://lh3.googleusercontent.com/gg/AJWXcNcpuvycdbMelCuZM_W1oJ2duv1hU4ygVYu9lIlN7RqaBOCqn8kbadC1aO_Wk5DEjjJmj3tKqMcW9YSMbffoHxPurTVhDlG4lrDAmh_dfGtuLs_WfeLpUzHR2wGGQTcjsJG7t9jpxGRNVvY5uaN5yeQLgg9uqAFqzD6qVlKNgrb_2xIat6OAhxvHal1WJFXUIss7Y08y4w0rcFnOBhP9IDaDWqezJcQnM_XK7aVy61wZsZ3cGRhfTwvPvdC2Bkp7DoqJtVrkWbfTmbzyd8LVLuZmWJ36HUpnA=s0',
    environment: 'City skyline grid, red/blue web mesh',
    loadout: ['Web Shooters', 'Spider-Sense HUD', 'Iron Spider Legs'],
    primaryColor: '#38bdf8',
    secondaryColor: '#1d4ed8',
    accentColor: '#ef4444',
    glowColor: 'rgba(56, 189, 248, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 30%, rgba(56, 189, 248, 0.16) 0%, rgba(10, 20, 40, 0.95) 75%, #030712 100%)',
    voiceQuote: 'I am Spider-Man',
    alternateQuote: 'When you can do the things that I can, but you don’t, and then the bad things happen, they happen because of you.',
    telemetry: {
      strength: 84,
      agilitySpeed: 99,
      energyProjection: 40,
      durability: 76,
      intelligenceTech: 92,
      custom1Name: 'Spider-Sense Reflex',
      custom1Value: 100,
      custom2Name: 'Web Tensile Strength',
      custom2Value: 94,
    },
    classification: 'BIO-ENHANCED DEFENDER',
    threatLevel: 'CLASS-A AGILE',
    bio: 'Mutated with precognitive spider-sense and wall-crawling biology. Peter designs micro-fluidic web shooters capable of stopping high-speed freight trains and executes aerial maneuvers across skyscraper canyons.'
  },
  {
    id: 'iron-man',
    number: '05',
    name: 'IRON MAN',
    identity: 'Tony Stark // Stark Tower',
    sourceFile: 'iron-man.jpg',
    image: '/iron-man.jpg',
    referenceUrl: 'https://lh3.googleusercontent.com/gg/AJWXcNf1dCg9YGfeBzLLl2szAaeoxh8Rxhw88pijpKZtryoppumAT9kRVY5pyLUp5VqvE_xUlvB6FXs-2BM6gz3SjNrkSrx6aopapWX5WUPjGPWwEN6LaIHHBUeGrn1RGvPbAfV83XsuOMlfvn6quV0lo_w2EZogDRJoxDGAL2NSIQs5XslvtYahz4E54UQtAckAj0kPrfBdAyjxPlAUHQr_CPXFN9bn6Fn4UwU00qMkEH1FDZFJYnbtlJLWBGncknpol7pl9e30BJn9oZrPn31lPhSGLy5AlQ9=s0',
    environment: 'Nanotech circuitry, red/gold reactor light',
    loadout: ['Mark L Armor', 'Arc Repulsors', 'Flight Thrusters'],
    primaryColor: '#f59e0b',
    secondaryColor: '#991b1b',
    accentColor: '#38bdf8',
    glowColor: 'rgba(245, 158, 11, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 30%, rgba(245, 158, 11, 0.18) 0%, rgba(35, 12, 10, 0.95) 75%, #030712 100%)',
    voiceQuote: 'I am Iron Man.',
    alternateQuote: 'Genius, billionaire, playboy, philanthropist.',
    telemetry: {
      strength: 85,
      agilitySpeed: 86,
      energyProjection: 92,
      durability: 88,
      intelligenceTech: 100,
      custom1Name: 'Nanotech Reconfiguration',
      custom1Value: 99,
      custom2Name: 'Repulsor Power Output',
      custom2Value: 96,
    },
    classification: 'VANGUARD TECHNOLOGIST',
    threatLevel: 'OMEGA-INVENTOR',
    bio: 'Architect of modern armored defense and central coordinator of the Avengers initiative. Operates the Mark L liquid-nanoparticle suit powered by a miniature palladium-free cold fusion Arc Reactor.'
  },
  {
    id: 'hulk',
    number: '06',
    name: 'HULK',
    identity: 'Bruce Banner // Gamma Lab',
    sourceFile: 'hulk.jpg',
    image: '/hulk.jpg',
    referenceUrl: 'https://lh3.googleusercontent.com/gg/AJWXcNfOn5R29Q4gumDfGWDxwjBT6007053mTN0SBXjK5ac9pijToOhHB8Kwtjzvg73k2f_pI7yT6Jp2wq4Zv3rnAZxQDUkvLVwR4OvQlmDLw6Uic_tVXvAN_8lTS7cliOwDklnMzuFC4fWO5P6G8JNgPWAW34ENof6L5tHHxv7AP8PlhRfGtce0JjfVBZF6Jkt_DfDdG_psAo9Q2DlmZJ_VzsGyo4Oi2jfatCAkM45jSjMMS3qxnZ0blvqtfgf_hrhbkyfTxx7N5B793ZkFIzP4VdJsqStjZuPKDA=s0',
    environment: 'Emerald radiation smoke, shockwave tremors',
    loadout: ['Gamma Surge', 'Ground Slam', 'Impact Roar'],
    primaryColor: '#10b981',
    secondaryColor: '#064e3b',
    accentColor: '#34d399',
    glowColor: 'rgba(16, 185, 129, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 30%, rgba(16, 185, 129, 0.18) 0%, rgba(8, 28, 16, 0.95) 75%, #030712 100%)',
    voiceQuote: 'I am Hulk',
    alternateQuote: "That's my secret, Cap... I'm always angry.",
    telemetry: {
      strength: 100,
      agilitySpeed: 75,
      energyProjection: 88,
      durability: 100,
      intelligenceTech: 96,
      custom1Name: 'Gamma Emission Surge',
      custom1Value: 100,
      custom2Name: 'Kinetic Impact Seismic',
      custom2Value: 99,
    },
    classification: 'GAMMA TITAN',
    threatLevel: 'EXTINCTION-SCALE',
    bio: 'Nuclear physicist transformed into an unstoppable emerald juggernaut of pure gamma fury. His physical strength, tissue density, and regenerative cellular repair scale without upper limit proportionally to heart-rate arousal.'
  },
  {
    id: 'hawkeye',
    number: '07',
    name: 'HAWKEYE',
    identity: 'Clint Barton // Strike Team',
    sourceFile: 'hawkeye.jpg',
    image: '/hawkeye.jpg',
    referenceUrl: 'https://lh3.googleusercontent.com/gg/AJWXcNdoUs4psdPIPdJYI1I3to_M_nPEA5t9egNl2Cn5S8bLWqLKzEWOHZiXhqSJeN0Hl0ajFwSTsH9PnsAWFLVtU_OsOOh5RWevf0vHkZTttgPVNuRFzh4Ny804AvRmsotDpZKbcmwSTeKmdpRgFvmfK4Ye6HyCUWzNtEmNczEtoIeUQ1MnNQgZ1_VSWhaYJeZz0l_aUip6ZKn73DUu8ICS4DioO9W-W1bs2Z0jSoKOqDmy6Qxe_z4icpo_VW4iYdH-D9fwCXz027xJ_KMa-Fvk3E5ue2BYVO5pw=s0',
    environment: 'Midnight purple HUD, optical crosshairs',
    loadout: ['Custom Recurve Bow', 'Trick Arrow Arsenal', 'Thermal Ronin Blades'],
    primaryColor: '#a855f7',
    secondaryColor: '#3b0764',
    accentColor: '#c084fc',
    glowColor: 'rgba(168, 85, 247, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 30%, rgba(168, 85, 247, 0.16) 0%, rgba(20, 10, 32, 0.95) 75%, #030712 100%)',
    voiceQuote: 'I am Hawkeye',
    alternateQuote: 'I see better from a distance.',
    telemetry: {
      strength: 52,
      agilitySpeed: 90,
      energyProjection: 48,
      durability: 58,
      intelligenceTech: 86,
      custom1Name: 'Ballistic Accuracy',
      custom1Value: 100,
      custom2Name: 'Tactical Warhead Payload',
      custom2Value: 95,
    },
    classification: 'PRECISION MARKSMAN',
    threatLevel: 'BALLISTIC-EXPERT',
    bio: 'Flawless marksman possessing supernatural eye-to-hand coordination and 360-degree tactical situational awareness. Employs modular trick arrows featuring sonic disruptors, grappling cables, and Pym particle charges.'
  },
  {
    id: 'captain-america',
    number: '08',
    name: 'CAPTAIN AMERICA',
    identity: 'Steve Rogers // First Avenger',
    sourceFile: 'captain-america.jpg',
    image: '/captain-america.jpg',
    referenceUrl: 'https://lh3.googleusercontent.com/gg/AJWXcNflDXlabCzqQUq9fK3flVP-i29sFr6xiR4EMjjhlQ1jB8J3YTjVjQmXlOkVlebnwBcL-R8Nz8FkbpE9an5tz7aiRqXi3IZSXMm-v3bw5-Tbq5u97ixh8k4sf4QzfEphTCNpHCMVoKTGcVRSlMphXScf-7gsZN0jlnGQdSu2yuZ9epIpN_7yNQ5GtoucG5DIzg03L7Zhd_jeLViBgJh0JWb8d059KUlnXUcw781hnxfFopctLiW92wGBLewuj0xmlmg7Ce57P7guuTAyltMWk7ID5Vf3jvdw=s0',
    environment: 'Starburst red/white/navy tactical grid',
    loadout: ['Vibranium Star Shield', 'Military Combat Gear', 'Field Command Transceiver'],
    primaryColor: '#3b82f6',
    secondaryColor: '#1e3a8a',
    accentColor: '#ef4444',
    glowColor: 'rgba(59, 130, 246, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 30%, rgba(59, 130, 246, 0.18) 0%, rgba(10, 18, 40, 0.95) 75%, #030712 100%)',
    voiceQuote: 'I am Captain America',
    alternateQuote: 'Avengers... Assemble!',
    telemetry: {
      strength: 86,
      agilitySpeed: 91,
      energyProjection: 30,
      durability: 93,
      intelligenceTech: 89,
      custom1Name: 'Tactical Command Presence',
      custom1Value: 100,
      custom2Name: 'Indomitable Moral Will',
      custom2Value: 100,
    },
    classification: 'FIELD COMMANDER',
    threatLevel: 'ALPHA-TACTICAL',
    bio: 'Peak-human supersoldier sculpted by Dr. Abraham Erskine’s serum formula and battle-tested across global theaters. Steve carries the unyielding vibranium alloy circular shield as both bulletproof defensive bastion and ricochet projectile.'
  },
  {
    id: 'doctor-strange',
    number: '09',
    name: 'DOCTOR STRANGE',
    identity: 'Stephen Strange // Kamar-Taj',
    sourceFile: 'doctor-strange.jpg',
    image: '/doctor-strange.jpg',
    referenceUrl: 'https://lh3.googleusercontent.com/gg/AJWXcNdZjM8XKZnr19sKXStPTi_n9HKN7IYgEe077JM5qMy8oMV9NDS0Dx_wBywztgJmcEwEJcQ4_SH1X-kWufp9GPsB9qchG_Y0eDaXVLEn7JvGwGWZL-u5Cf9LNn1SX7Iy57qvZPFcFB4buS8GpXM658XjgH5cLdJu6XZTOoUeMCdMUJEyPRN_2n_bdhc3ZU8Ruh4IKJ07a22gDRX1h80_F8DqSrncFKWbmpwmR4ZPR6XIT77LYDSyLMPbSLtzy1BnaSRtQ_ovywwkCQC8W1KVdTm2-SUjb-cvFw=s0',
    environment: 'Eldritch sparks, orange mystic mandala portal',
    loadout: ['Eye of Agamotto', 'Cloak of Levitation', 'Sling Ring'],
    primaryColor: '#ea580c',
    secondaryColor: '#7c2d12',
    accentColor: '#fbbf24',
    glowColor: 'rgba(234, 88, 12, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 30%, rgba(234, 88, 12, 0.18) 0%, rgba(30, 15, 8, 0.95) 75%, #030712 100%)',
    voiceQuote: 'I am Doctor Strange',
    alternateQuote: "Dormammu, I've come to bargain.",
    telemetry: {
      strength: 60,
      agilitySpeed: 82,
      energyProjection: 100,
      durability: 84,
      intelligenceTech: 98,
      custom1Name: 'Mystic Arts Mastery',
      custom1Value: 100,
      custom2Name: 'Temporal Dimensional Arc',
      custom2Value: 97,
    },
    classification: 'MASTER OF MYSTIC ARTS',
    threatLevel: 'REALM-GUARDIAN',
    bio: 'Former neurosurgeon who unlocked the sacred cosmic sanctums of Kamar-Taj. Weaves eldritch tao mandalas, harnesses the Cloak of Levitation for aerial mobility, and peers across multiversal timelines to safeguard Earth from interdimensional cataclysm.'
  }
];
